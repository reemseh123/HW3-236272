import 'package:english_words/english_words.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum Status { unInitialized, authenticated, authenticating, unAuthenticated }

class StateManagement with ChangeNotifier {
  final FirebaseAuth _auth;
  User? _user;
  Status _status = Status.unInitialized;
  CollectionReference users = FirebaseFirestore.instance.collection('users');
  final FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;
  Set<WordPair> savedData = {};

  StateManagement.instance() : _auth = FirebaseAuth.instance {
    _auth.authStateChanges().listen(_onAuthStateChanged);
    _user = _auth.currentUser;
    _onAuthStateChanged(_user);
  }

  Status get status => _status;

  User? get user => _user;

  bool get isAuthenticated => status == Status.authenticated;

  Future<UserCredential?> signUp(String email, String password, Set<WordPair> favorites) async {
    try {
      _status = Status.authenticating;
     // addUser(favorites);
      notifyListeners();
      return await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
    } catch (e) {
      _status = Status.unAuthenticated;
      notifyListeners();
      return null;
    }
  }

  Future<bool> signIn(String email, String password) async {
    try {
      _status = Status.authenticating;
      notifyListeners();
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return true;
    } catch (e) {
      _status = Status.unAuthenticated;
      notifyListeners();
      return false;
    }
  }

  Future signOut() async {
    _auth.signOut();
    _status = Status.unAuthenticated;
    notifyListeners();
    return Future.delayed(Duration.zero);
  }

  Future<void> _onAuthStateChanged(User? firebaseUser) async {
    if (firebaseUser == null) {
      _user = null;
      _status = Status.unAuthenticated;
    } else {
      _user = firebaseUser;
      _status = Status.authenticated;
    }
    notifyListeners();
  }
  Future<void> addUser(Set<WordPair> favorites) {
    // Call the user's CollectionReference to add a new user
    return users
        .add({
      'Saved_favorites': favorites.map((wp) => wp.asPascalCase).toList(), // John Doe
    });
  }
  Future<void> updateFavorite(WordPair pair, bool delete) async {
    // Map<String,Object?> newList = newSet.map((wp) => wp.asPascalCase) as Map<String, Object?>;///.toList();
     delete?
     await _firebaseFirestore.collection('users')
         .doc(_user!.uid)
         .collection('Saved Suggestions')
         .doc(pair.toString()).delete():
     await _firebaseFirestore.collection('users').doc(_user!.uid)
          .collection('Saved Suggestions')
          .doc(pair.toString())
          .set({'first': pair.first, 'second': pair.second});
     notifyListeners();
    }
  Future<void> updateFavorites(Set<WordPair> pairs) async {
    // Map<String,Object?> newList = newSet.map((wp) => wp.asPascalCase) as Map<String, Object?>;///.toList();
    for (var pair in pairs) {
       await _firebaseFirestore.collection('users').doc(_user!.uid)
           .collection('Saved Suggestions')
           .doc(pair.toString())
           .set({'first': pair.first, 'second': pair.second});
    }
    notifyListeners();
  }

    Future<Set<WordPair>?> getFutureData() async {
      Set<WordPair> savedSuggestions = <WordPair>{};
      String first, second;
      await _firebaseFirestore.collection('users')
          .doc(_user!.uid)
          .collection('Saved Suggestions')
          .get()
          .then((querySnapshot) {
        for (var result in querySnapshot.docs) {
          first = result.data().entries.first.value.toString();
          second = result.data().entries.last.value.toString();
          savedSuggestions.add(WordPair(first, second));
        }
      });
      return Future<Set<WordPair>>.value(savedSuggestions);
    }
  Future<Set<WordPair>?> getFinalData() async {
    return await getFutureData();
  }

}
