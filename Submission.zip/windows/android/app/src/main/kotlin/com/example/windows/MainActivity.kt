package com.example.windows

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
